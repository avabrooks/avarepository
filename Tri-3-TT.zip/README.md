# AP CSA Trimester 3: 

Welcome to Ava's Repl for all Tech Talks for Trimester 3!
  


  
