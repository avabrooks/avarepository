javac src/Menu.java
java src/Menu
rm src/*.class